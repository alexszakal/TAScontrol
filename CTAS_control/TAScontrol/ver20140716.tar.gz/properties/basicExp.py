
class BasicExperiment():
    def __init__(self, user='CNTAS_user', title='Exp.Title'):
        self.user=user
        self.title=title
    