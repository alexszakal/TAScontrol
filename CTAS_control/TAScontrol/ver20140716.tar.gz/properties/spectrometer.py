from numpy import *
import pickle

from sample import *
from basicSpectrometer import *
from collections import OrderedDict
from TAScontrol.others.filePath import *


class Spectrometer(basicSpectrometer):
    def __init__(self, name=''):
        if name=='':
            self.d_monok=3.35395
            self.d_ana=3.35395
            self.scattSign=matrix('1 1 1')
            self.lock=['ki',2.5618]
            self.colli=[600,30,60,60]
            self.ROI=[1,128,1,128]
            self.axisOffsetDict=OrderedDict([ ('mvfoc',0), ('monok',-0.45), ('monho',0),\
            ('s2th',0),('om',0),('ath',0),('sadist',0),('detang',1.5),\
            ('mtrX',0), ('mtrY',0), ('mgL',0), ('mgU',0), ('s1X', 0),\
            ('s1Y',0), ('s1L',0), ('s1U',0), ('s2X',0), ('s2Y',0),\
            ('s2L',0), ('s2U',0), ('strX',0), ('strY',0), ('agU',0),\
            ('agL',0), ('antrX', 0), ('antrY',0), ('angU',0), ('angL',0),\
            ('detdist',0), ('msdist',0), ('anShRot',0), ('anShLift', 0),\
            ('sgL', 0), ('sgU', 0)])
            self.axisLimitsDict=OrderedDict( [ ('mvfoc',[0,100]), ('monok',[10,70]), ('monho',[30,70]),\
            ('s2th',[-70,70]),('om',[0,355]),('ath',[0,180]),('sadist',[400,600]),('detang',[-70,70]),\
            ('mtrX',[-10,10]), ('mtrY',[-10,10]), ('mgL',[-10,10]), ('mgU',[-10,10]), ('s1X', [0,60]),\
            ('s1Y',[0,60]), ('s1L',[0,60]), ('s1U',[0,60]), ('s2X',[0,60]), ('s2Y',[0,60]),\
            ('s2L',[0,60]), ('s2U',[0,60]), ('strX',[-20,20]), ('strY',[-20,20]),\
            ('antrX', [-20,20]), ('antrY',[-20,20]), ('angU',[-5,5] ), ('angL',[-5,5]),\
            ('detdist',[600,1000]), ('msdist',[1000,1500]), ('anShRot',[0,14]), ('anShLift', [0,600]),\
            ('sgL', [-15,15]), ('sgU', [-15,15]) ] )
            
            
        else:        
            spectrometerData=pickle.load(open(configDataPath+name+'.bin', 'rb'))
            self.d_monok=spectrometerData.d_monok
            self.d_ana=spectrometerData.d_ana
            
            self.scattSign=spectrometerData.scattSign
            self.lock=spectrometerData.lock
            self.colli=spectrometerData.colli
            self.ROI=spectrometerData.ROI
            self.axisOffsetDict=spectrometerData.axisOffsetDict
            self.axisLimitsDict=spectrometerData.axisLimitsDict
            

    def save(self, filname='actSpect'):
        tmpS=basicSpectrometer(self.d_monok, self.d_ana, self.scattSign, self.lock, self.colli, self.ROI, self.axisOffsetDict, self.axisLimitsDict)
        pickle.dump(tmpS, open(configDataPath+filname+'.bin', 'wb'))
    
    def calcHKLE(self, h, k, l, E):
        #Definition of reciprocal lattice point, dE, Ei
        hkl=matrix('{0:.4} {1:.4} {2:.4}'.format(float(h), float(k), float(l)))
        
        if(self.lock[0] == 'ki'):
            ki=self.lock[1]
            lam_i=2*pi/ki
            Ei=81.808/pow(lam_i,2)
            A1=rad2deg(arcsin(lam_i/2/self.d_monok)*self.scattSign.item(0))
            
            Ef=Ei-E
            lam_f=sqrt(81.808/Ef)
            kf=2*pi/lam_f
            A5=rad2deg(arcsin(lam_f/2/self.d_ana)*self.scattSign.item(2) )
        elif(self.lock[0] == 'kf'):
            kf=self.lock[1]
            lam_f=2*pi/kf
            Ef=81.808/pow(lam_f,2)
            A5=rad2deg(arcsin(lam_f/2/self.d_ana)*self.scattSign.item(2) )

            Ei=Ef+E
            lam_i=sqrt(81.808/Ei)
            ki=2*pi/lam_i
            A1=rad2deg( arcsin(lam_i/2/self.d_monok)*self.scattSign.item(0) )
        
        B=actSample.B
        UB=actSample.UB
        h1=actSample.pVec[0,0:3].T
        h2=actSample.pVec[1,0:3].T
        #   Scattering angle
        qabs=linalg.norm(dot(B,hkl.T))
        phi=rad2deg( arccos( (pow(ki,2) + pow(kf,2) - pow(qabs,2))/(2*ki*kf) ) ) * self.scattSign.item(1)
        #   Theta angle
        theta = rad2deg( arctan( (ki-kf*cos(deg2rad(phi))) / (kf*sin(deg2rad(phi))) ) )

        #   Vector normal to the plane h1 h2
        uh1nu=dot(UB,h1) / linalg.norm( dot(UB,h1) )    #h1 in the nu coordinate system
        uh2nu=dot(UB,h2) / linalg.norm( dot(UB,h2) )    #h2 in the nu coordinate system
        uPlaneNormal=cross(uh1nu.T, uh2nu.T)

        #   Normalized Q  (u1nu)in the nu coordinate system:
        u1nu = dot( UB, hkl.T) / linalg.norm( dot( UB, hkl.T) )
        #   u2nu (perpendicular to (u1nu anduPlaneNormal)
        u2nu = cross(uPlaneNormal, u1nu.T)

        #   Calculate the T matrix
        T=zeros((3,3))
        #       First column: u1nu
        T[0][0]=u1nu[0][0]
        T[1][0]=u1nu[1][0]
        T[2][0]=u1nu[2][0]
        #       Second column: u2nu
        T[0][1]=u2nu[0][0]
        T[1][1]=u2nu[0][1]
        T[2][1]=u2nu[0][2]
        #       Third column: cross(u1nu, u2nu)
        t3nu=cross(u1nu.T, u2nu)
        T[0][2]=t3nu[0][0]
        T[1][2]=t3nu[0][1]
        T[2][2]=t3nu[0][2]

        #   Calculation of the R matrix
        R=linalg.inv(T)
        #   Calculation of the angles
        mu=rad2deg( arctan(-1*R[2][0] / (sqrt(pow(R[0][0],2) + pow(R[1][0],2) ) )) )
        nu=rad2deg( arctan(R[2][1] / R[2][2] ) )
        omega=rad2deg( arctan(R[1][0] / R[0][0] ) )
        s=omega + theta

        return [A1, 2*A1, s, phi, A5, 2*A5, mu, nu]


    
global actSpect
actSpect=Spectrometer('actSpect')