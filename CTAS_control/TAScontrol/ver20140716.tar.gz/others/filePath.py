
dataPath='/home/cntas/CTAS_data/'
logPath='/home/cntas/CTAS_data/logFiles/'
logFullPath='/home/cntas/CTAS_data/logFullFiles/'
configDataPath="/home/cntas/CTAS_control/"

